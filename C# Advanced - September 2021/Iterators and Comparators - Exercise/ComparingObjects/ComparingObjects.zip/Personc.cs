﻿namespace ComparingObjects
{
    public class Personc
    {
    }
}