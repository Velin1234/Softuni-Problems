﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person1 = new Person();
            person1.Name = "George";
            person1.Age = 33;
            Person person2 = new Person("Ivan",25);
        }
    }
}
