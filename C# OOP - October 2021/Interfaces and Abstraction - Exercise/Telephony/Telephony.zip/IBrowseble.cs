﻿namespace Telephony
{
    public interface IBrowseble
    {
        string Browse(string Url);
    }
}