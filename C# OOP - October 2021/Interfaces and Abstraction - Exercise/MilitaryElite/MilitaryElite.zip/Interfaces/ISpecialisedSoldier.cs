﻿namespace MilitaryElite
{
    public interface ISpecialisedSoldier
    {
        string Corps { get; set; }
    }
}