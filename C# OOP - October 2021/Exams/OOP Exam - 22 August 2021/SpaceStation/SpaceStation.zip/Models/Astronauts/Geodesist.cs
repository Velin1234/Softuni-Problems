﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SpaceStation.Models.Astronauts
{
    internal class Geodesist : Astronaut
    {
        public Geodesist(string name) : base(name,50)
        {
        }
    }
}
